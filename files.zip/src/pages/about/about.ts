import { Component } from '@angular/core';
import { NavController,NavParams } from 'ionic-angular';
import { Geolocation, Geoposition } from '@ionic-native/geolocation';
declare var google;

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {
  public map: any = null;
  public trackerLine: any = null;
  public markerInicio: any = null;
  public ruta: object = {};

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private geolocation: Geolocation,
  ) {
    this.ruta = this.navParams.get('ruta');
    console.log(this.ruta); 
  }

  ionViewDidLoad() {
    //this.getPosition();
    this.loadMap();
  }

  getPosition():any{
    this.geolocation.getCurrentPosition()
    .then(response => {
      //this.loadMap(response);
      //console.log(response);
    })
    .catch(error =>{
      console.log(error);
    })
  }

  loadMap(){
  //loadMap(position: Geoposition){
    //let latitude = position.coords.latitude;
    //let longitude = position.coords.longitude;
    let latitude = -15.8368951;
    let longitude = -70.0220128;
    
    //console.log(latitude, longitude);
    
    // create a new map by passing HTMLElement
    let mapEle: HTMLElement = document.getElementById('map2');

    // create LatLng object
    let myLatLng = {lat: latitude, lng: longitude};

    // create map
    this.map = new google.maps.Map(mapEle, {
      center: myLatLng,
      zoom: 12
    });

    if(this.ruta['coordenadas'].length > 0 ){
      this.trackerLine = new google.maps.Polyline({
        path: this.ruta['coordenadas'],
        geodesic: true,
        strokeColor: '#5369ff',
        strokeOpacity: 1.0,
        strokeWeight: 2
      });
    
      this.trackerLine.setMap(this.map);
      this.zoomToObject(this.trackerLine);
    }
    google.maps.event.addListenerOnce(this.map, 'idle', () => {
      /*
      this.markerInicio = new google.maps.Marker({
        position: myLatLng,
        map: this.map,
        title: 'Hello World!'
      });
      */
      mapEle.classList.add('show-map');
    });

  }

  zoomToObject(obj){
    var bounds = new google.maps.LatLngBounds();
    var points = obj.getPath().getArray();
    for (var n = 0; n < points.length ; n++){
        bounds.extend(points[n]);
    }
    this.map.fitBounds(bounds);
}

}
