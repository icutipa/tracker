import { Injectable } from '@angular/core';

import { Toast } from '@ionic-native/toast';
import { Storage } from '@ionic/storage';

@Injectable()
export class DatabaseProvider {
  public DB_STORAGE = "DB_RUTAS";
  constructor(
    private toast: Toast,
    public storage: Storage
  ) {
    
  }

  add(item) {
    var arrayData = [];
    this.getAll().then( (result)=>{
      if( result && result.length > 0 ){
        arrayData = result;
        arrayData.push(item);
      }else{
        arrayData.push(item);
      }
      this.remove();
      return this.storage.set(this.DB_STORAGE,arrayData);
      
    });
  }
  update(arrayData){
    this.remove();
    return this.storage.set(this.DB_STORAGE,arrayData);
  }
  remove() {
  	return this.storage.remove(this.DB_STORAGE);
  }

  getAll() {
  	return this.storage.get(this.DB_STORAGE);
  }

  

}