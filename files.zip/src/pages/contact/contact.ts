import { Component } from '@angular/core';
import { NavController,NavParams, AlertController } from 'ionic-angular';
import { DatabaseProvider } from '../../providers/database/database';
import { AboutPage } from '../about/about';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {
  public rutas: any = [];
  constructor(
    public navCtrl: NavController,
    public database: DatabaseProvider,
    public navParams: NavParams,
    public alertCtrl: AlertController,
  ) {

  }
  ionViewWillEnter(){
    this.database.getAll().then( (result)=>{
      if( result && result.length > 0 ){
        this.rutas = result;
      }
    });
  }
  ionViewDidLoad(){
  
  }

  detalleRuta(ruta){
    this.navCtrl.push(AboutPage,{ruta:ruta});
  }
  eliminarRuta(ruta, index){
    this.showEliminarConfirm(ruta, index);
  }

  showEliminarConfirm( ruta, index ) {
    const confirm = this.alertCtrl.create({
      title: 'Eliminar Ruta',
      message: 'esta seguro que quieres eliminar la ruta '+ruta['nombre']+'?',
      buttons: [
        {
          text: "Cancelar",
          handler: () => {
            
          }
        },
        {
          text: 'Eliminar',
          handler: () => {
            this.rutas.splice(index,1);
            this.database.update(this.rutas).then();
          }
        }
      ]
    });
    confirm.present();
  }
}