import { Component } from '@angular/core';
import { NavController, AlertController } from 'ionic-angular';
import { Platform } from 'ionic-angular';
import { Geolocation, Geoposition } from '@ionic-native/geolocation';

import { LocationTrackerProvider } from '../../providers/location-tracker/location-tracker';
import { DatabaseProvider } from '../../providers/database/database';
//import { Diagnostic } from '@ionic-native/diagnostic';

declare var google;

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public map: any = null;
  public trackerLine: any = null;
  public markerInicio: any = null;
  public coordenadas: any = [];
  public estadoInterval: any = null;
  public almacenarCoordenadas: Boolean = false;
  public btnIniciar: Boolean = false;
  public btnFinalizar: Boolean = true;

  constructor(
    public navCtrl: NavController,
    private platform: Platform,
    private geolocation: Geolocation,
    public locationTracker: LocationTrackerProvider,
    public database: DatabaseProvider,
    public alertCtrl: AlertController,
    //public diagnostic: Diagnostic,
  ) {

  }
  ionViewWillEnter(){
    //if (this.platform.is('cordova')) {
    //  this.locationTracker.startTracking();
    //}
  }
  /*
  ionViewWillEnter(){
    this.diagnostic.isGpsLocationEnabled().then((result)=>{
      if ( !result ) {
        let confirm = this.alertCtrl.create({
              title: '<b>GPS</b>',
              message: 'El GPS está deshabilitado. Habilite desde configuraciones para que el aplicativo pueda funcionar mejor.',
              buttons: [
                {
                  text: 'GO TO SETTINGS',
                    handler: () => {
                      this.diagnostic.switchToLocationSettings();
                    }
                }
              ]
            });
            confirm.present();      
        }
    }).catch((error)=>{
      console.log("ERROR GPS: ",error);
    });
    return //your check;
  }
*/
  ionViewDidLoad(){
    //this.loadMap();
    this.getPosition();
    this.estadoInterval = setInterval(()=>{
      if( this.almacenarCoordenadas === true ){
        if( this.locationTracker.lat != 0 || this.locationTracker.lng != 0 ){
          if( this.coordenadas.length > 0 ){
            if( this.coordenadas[this.coordenadas.length-1].lat != this.locationTracker.lat || this.coordenadas[this.coordenadas.length-1].lng != this.locationTracker.lng  ){
              this.coordenadas.push(
                {
                  "lat": this.locationTracker.lat,
                  "lng": this.locationTracker.lng,
                }
              );
            }
          }else{
            this.coordenadas.push(
              {
                "lat": this.locationTracker.lat,
                "lng": this.locationTracker.lng,
              }
            );
            this.markerInicio = new google.maps.Marker({
              position: {lat: this.coordenadas[0].lat, lng: this.coordenadas[0].lng},
              map: this.map,
              title: 'Punto de Partida'
            });
          }
        }
      }
      if( this.coordenadas.length >= 2 ){
        var flightPlanCoordinates = [
          {lat:this.coordenadas[this.coordenadas.length-1].lat, lng:this.coordenadas[this.coordenadas.length-1].lng},
          {lat:this.coordenadas[this.coordenadas.length-2].lat, lng:this.coordenadas[this.coordenadas.length-2].lng}
        ];
        this.trackerLine = new google.maps.Polyline({
          path: flightPlanCoordinates,
          geodesic: true,
          strokeColor: '#5369ff',
          strokeOpacity: 1.0,
          strokeWeight: 2
        });
      
        this.trackerLine.setMap(this.map);
      }      
    }, 3000);
    //this.locationTracker.startTracking();
    
  }

  start(){
    
    //if( this.trackerLine ){
      //this.trackerLine.setMap(null);
    //}

    this.btnIniciar = true;
    this.btnFinalizar = false;
    this.almacenarCoordenadas = true;
    if (this.platform.is('cordova')) {
      this.locationTracker.startTracking();
    }
  }

  stop(){
    this.btnIniciar = false;
    this.btnFinalizar = true;
    this.almacenarCoordenadas = false;
    //console.log(JSON.stringify(this.coordenadas));
    this.showPrompt();
    //this.coordenadas.length = 0;
    //this.locationTracker.stopTracking();    
    
  }  

  getPosition():any{
    this.geolocation.getCurrentPosition()
    .then(response => {
      this.loadMap(response);
      console.log(response);
    })
    .catch(error =>{
      console.log(error);
    })
  }

  //loadMap(){
  loadMap(position: Geoposition){
    //let latitude = position.coords.latitude;
    //let longitude = position.coords.longitude;
    let latitude = -15.8368951;
    let longitude = -70.0220128;
    
    console.log(latitude, longitude);
    
    // create a new map by passing HTMLElement
    let mapEle: HTMLElement = document.getElementById('map');

    // create LatLng object
    let myLatLng = {lat: latitude, lng: longitude};

    // create map
    this.map = new google.maps.Map(mapEle, {
      center: myLatLng,
      zoom: 12
    });

    
    google.maps.event.addListenerOnce(this.map, 'idle', () => {
      /*
      this.markerInicio = new google.maps.Marker({
        position: myLatLng,
        map: this.map,
        title: 'Hello World!'
      });
      */
      mapEle.classList.add('show-map');
    });

  }
 
  showPrompt( nombre = "") {
    const prompt = this.alertCtrl.create({
      title: 'Guardar Ruta',
      message: "Escribe un nombre para tu ruta",
      inputs: [
        {
          name: 'nombre',
          placeholder: 'Nombre',
          value: nombre, 
        },
      ],
      buttons: [
        {
          text: 'Cancelar',
          handler: data => {
            this.showCancelConfirm(data.nombre);
          }
        },
        {
          text: 'Guardar',
          handler: data => {
            this.database.add({
              "nombre":data.nombre,
              "coordenadas": this.coordenadas,
            });
            this.showConfirmAlert();
            this.getPosition();
          }
        }
      ]
    });
    prompt.present();
  }
  showConfirmAlert() {
    const alert = this.alertCtrl.create({
      title: 'Ruta Guardada',
      subTitle: 'la información ha sido guardado con éxito..!',
      buttons: [
        {
          text: 'OK',
          handler: () => {
            this.coordenadas.length = 0;
          }
        }
      ]
    });
    alert.present();
  }
  showCancelConfirm( nombre = "" ) {
    const confirm = this.alertCtrl.create({
      title: 'Cancelar Ruta',
      message: 'Perderás toda la información de la ruta, aceptas no guardar la ruta?',
      buttons: [
        {
          text: "Cancelar",
          handler: () => {
            this.showPrompt(nombre);
          }
        },
        {
          text: 'Acepto',
          handler: () => {

          }
        }
      ]
    });
    confirm.present();
  }
}